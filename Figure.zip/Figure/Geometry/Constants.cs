namespace Geometry
{
	public static class Constants
	{
		public const double CalculationAccuracy = 1e-7;
	}
}