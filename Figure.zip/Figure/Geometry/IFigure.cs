namespace Geometry
{
	public interface IFigure
	{
		double GetSquare();
	}
}